import React,{useEffect,useRef,useState} from "react";
import {createRoot} from "react-dom/client";
import {Send,Mic,Volume2,Square,Plus,Trash2,Menu,X,Copy,Sun,Moon,Settings} from "lucide-react";
import "./styles.css";

type Msg={role:"user"|"assistant",content:string};
const KEY="ariya_messages_v1";
const SYSTEM="You are ARIYA AI, a friendly, intelligent and helpful female AI assistant. Communicate naturally in Hindi or English according to the user. Be honest about uncertainty and never claim actions you did not perform.";

function App(){
 const [messages,setMessages]=useState<Msg[]>(()=>JSON.parse(localStorage.getItem(KEY)||"[]"));
 const [input,setInput]=useState(""); const [busy,setBusy]=useState(false);
 const [dark,setDark]=useState(()=>localStorage.getItem("ariya_dark")==="1");
 const [drawer,setDrawer]=useState(false); const [listening,setListening]=useState(false);
 const [speaking,setSpeaking]=useState(false); const abortRef=useRef<AbortController|null>(null);
 useEffect(()=>localStorage.setItem(KEY,JSON.stringify(messages)),[messages]);
 useEffect(()=>localStorage.setItem("ariya_dark",dark?"1":"0"),[dark]);

 function newChat(){setMessages([]);setInput("");setDrawer(false)}
 async function send(){
   const text=input.trim(); if(!text||busy)return;
   const next=[...messages,{role:"user" as const,content:text}]; setMessages(next); setInput(""); setBusy(true);
   const controller=new AbortController(); abortRef.current=controller;
   try{
    const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:[{role:"system",content:SYSTEM},...next]}),signal:controller.signal});
    if(!r.ok) throw new Error("AI request failed");
    const data=await r.json(); setMessages([...next,{role:"assistant",content:data.content||"मुझे अभी जवाब नहीं मिला।"}]);
   }catch(e:any){
    if(e.name!=="AbortError") setMessages([...next,{role:"assistant",content:"अभी ARIYA की AI service उपलब्ध नहीं है। API/backend configure करने के बाद मैं जवाब दे पाऊँगी।"}]);
   }finally{setBusy(false);abortRef.current=null}
 }
 function stop(){abortRef.current?.abort();setBusy(false)}
 function voice(){
   const SR=(window as any).SpeechRecognition||(window as any).webkitSpeechRecognition;
   if(!SR){alert("इस browser में voice input उपलब्ध नहीं है।");return}
   const r=new SR();r.lang="hi-IN";r.interimResults=false;r.onstart=()=>setListening(true);r.onend=()=>setListening(false);
   r.onresult=(e:any)=>setInput((v)=>v+" "+e.results[0][0].transcript);r.start();
 }
 function speak(t:string){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang=/[\u0900-\u097F]/.test(t)?"hi-IN":"en-US";u.onend=()=>setSpeaking(false);setSpeaking(true);speechSynthesis.speak(u)}
 const empty=messages.length===0;
 return <div className={dark?"app dark":"app"}>
  <header><button className="icon" onClick={()=>setDrawer(!drawer)}>{drawer?<X/>:<Menu/>}</button><div className="brand"><div className="avatar">A</div><div><b>ARIYA AI</b><small>आपकी अपनी स्मार्ट AI साथी</small></div></div><div className="headActions"><button className="icon" onClick={()=>setDark(!dark)}>{dark?<Sun/>:<Moon/>}</button><button className="icon" onClick={newChat}><Plus/></button></div></header>
  <aside className={drawer?"drawer open":"drawer"}><div className="sideTitle">Chats</div><button className="new" onClick={newChat}><Plus/> New Chat</button>{messages.length>0&&<div className="history">Current conversation</div>}<div className="sideBottom"><Settings size={17}/> Settings</div></aside>
  <main>
   {empty?<section className="welcome"><div className="heroAvatar">A</div><h1>नमस्ते, मैं ARIYA हूँ 💕</h1><p>आप मुझसे कुछ भी पूछ सकते हैं। मैं सवालों, writing, पढ़ाई, ideas और coding में आपकी मदद कर सकती हूँ।</p><div className="quick">{["कुछ पूछें","कुछ लिखवाएँ","पढ़ाई में मदद","Ideas चाहिए","Code बनवाएँ","Translate करें"].map(x=><button key={x} onClick={()=>setInput(x+" — ")}>{x}</button>)}</div></section>
   :<section className="messages">{messages.map((m,i)=><div className={m.role==="user"?"row user":"row"} key={i}><div className="bubble">{m.role==="assistant"&&<div className="mini">A</div>}<div className="content">{m.content}</div>{m.role==="assistant"&&<div className="actions"><button onClick={()=>navigator.clipboard?.writeText(m.content)}><Copy size={14}/></button><button onClick={()=>speak(m.content)}><Volume2 size={14}/></button></div>}</div></div>)}{busy&&<div className="row"><div className="bubble typing"><div className="mini">A</div><span></span><span></span><span></span></div></div>}</section>}
   <div className="composer"><div className="inputbox"><textarea value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}}} placeholder="कुछ भी पूछिए..." rows={1}/><div className="tools"><button onClick={voice} className={listening?"active":""}><Mic size={19}/></button><button onClick={busy?stop:send} className="send">{busy?<Square size={17}/>:<Send size={18}/>}</button></div></div><small>ARIYA AI • आपके संदेश सुरक्षित रखने के लिए browser storage का उपयोग करता है</small></div>
  </main>
 </div>
}
createRoot(document.getElementById("root")!).render(<App/>);