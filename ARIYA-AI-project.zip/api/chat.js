export default async function handler(req,res){
 if(req.method!=="POST") return res.status(405).json({error:"Method not allowed"});
 try{
  const {messages}=req.body||{};
  if(!Array.isArray(messages)||!messages.length) return res.status(400).json({error:"messages required"});
  const key=process.env.AI_API_KEY, base=process.env.AI_BASE_URL||"https://api.openai.com/v1", model=process.env.AI_MODEL;
  if(!key||!model) return res.status(503).json({error:"AI not configured"});
  const r=await fetch(`${base.replace(/\/$/,"")}/chat/completions`,{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`},body:JSON.stringify({model,messages,temperature:0.7})});
  const data=await r.json(); if(!r.ok) return res.status(r.status).json({error:"AI provider error"});
  return res.status(200).json({content:data.choices?.[0]?.message?.content||""});
 }catch(e){return res.status(500).json({error:"Server error"})}
}